/**
 * TÜPRAG MADEN İŞLETMESİ
 * Güvenlik Kontrol Paneli - Ana Uygulama Mantığı
 * app.js
 * 
 * TCP bağlantısı WebSocket üzerinden simüle edilmektedir.
 * Gerçek TCP bağlantısı için arka uç (Python/Node.js) sunucu gereklidir.
 */

'use strict';

// ==================== STATE ====================
const state = {
    seatbelt: false,   // true = ALERT (kemer takılı değil)
    seat:     false,   // true = ALERT (operatör kalktı)
    door:     false,   // true = ALERT (kapı açık)
    alertCount: 0,
    startTime: Date.now(),
    tcpConnected: false,
    ws: null,
    pollingInterval: null,
    activeAlerts: new Set()
};

// TCP Config
let tcpConfig = {
    ip:   '192.168.1.100',
    port: 502,
    poll: 1000
};

// ==================== DOM ELEMENTS ====================
const els = {
    time:        document.getElementById('current-time'),
    date:        document.getElementById('current-date'),
    tcpDot:      document.getElementById('tcp-indicator'),
    tcpLabel:    document.getElementById('tcp-label'),
    tcpAddress:  document.getElementById('tcp-address'),
    statUptime:  document.getElementById('stat-uptime'),
    safetyArc:   document.getElementById('safety-arc'),
    scoreNumber: document.getElementById('score-number'),
    connectBtn:  document.getElementById('connect-btn'),

    // Cards
    cardSeatbelt:  document.getElementById('card-seatbelt'),
    cardSeat:      document.getElementById('card-seat'),
    cardDoor:      document.getElementById('card-door'),

    // LED indicators
    ledSeatbelt: document.querySelector('#card-seatbelt .sensor-led'),
    ledSeat:     document.querySelector('#card-seat .sensor-led'),
    ledDoor:     document.querySelector('#card-door .sensor-led'),

    // Status texts
    txtSeatbelt: document.querySelector('#card-seatbelt .sensor-status-text'),
    txtSeat:     document.querySelector('#card-seat .sensor-status-text'),
    txtDoor:     document.querySelector('#card-door .sensor-status-text'),

    // Overlays
    overlaySeatbelt: document.getElementById('overlay-seatbelt'),
    overlaySeat:     document.getElementById('overlay-seat'),
    overlayDoor:     document.getElementById('overlay-door')
};

// ==================== CLOCK & UPTIME ====================
function updateClock() {
    const now = new Date();
    const timeStr = now.toTimeString().slice(0, 8);
    const days = ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'];
    const months = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran',
                    'Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
    const dateStr = `${days[now.getDay()]} ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
    
    if (els.time) els.time.textContent = timeStr;
    if (els.date) els.date.textContent = dateStr;
}

function updateUptime() {
    const elapsed = Math.floor((Date.now() - state.startTime) / 1000);
    const mins = Math.floor(elapsed / 60).toString().padStart(2, '0');
    const secs = (elapsed % 60).toString().padStart(2, '0');
    if (els.statUptime) els.statUptime.textContent = `${mins}:${secs}`;
}

// ==================== ALERT SYSTEM ====================
/**
 * triggerAlert - Uyarıyı tetikle veya sıfırla
 * @param {string} type - 'seatbelt' | 'seat' | 'door'
 * @param {boolean} isAlert - true = alert, false = normal
 */
function triggerAlert(type, isAlert) {
    if (state[type] === isAlert) return; // Değişiklik yoksa işlem yapma
    state[type] = isAlert;

    const cfg = {
        seatbelt: {
            overlay: els.overlaySeatbelt,
            card: els.cardSeatbelt,
            led: els.ledSeatbelt,
            txt: els.txtSeatbelt,
            alertClass: 'alert-state',
            ledClass: 'alert-red',
            alertText: 'TAKILMADI!',
            safeText: 'TAKILDI',
            logClass: 'red-log',
            logIcon: '🔴',
            logName: 'Emniyet Kemeri'
        },
        seat: {
            overlay: els.overlaySeat,
            card: els.cardSeat,
            led: els.ledSeat,
            txt: els.txtSeat,
            alertClass: 'seat-alert',
            ledClass: 'alert-orange',
            alertText: 'KALKMIŞTI!',
            safeText: 'OTURUYOR',
            logClass: 'orange-log',
            logIcon: '🟠',
            logName: 'Operatör Oturumu'
        },
        door: {
            overlay: els.overlayDoor,
            card: els.cardDoor,
            led: els.ledDoor,
            txt: els.txtDoor,
            alertClass: 'door-alert',
            ledClass: 'alert-yellow',
            alertText: 'AÇIK!',
            safeText: 'KAPALI',
            logClass: 'yellow-log',
            logIcon: '🟡',
            logName: 'Kapı'
        }
    };

    const c = cfg[type];
    if (!c) return;

    if (isAlert) {
        // Show alert overlay
        c.overlay.style.display = 'flex';
        requestAnimationFrame(() => {
            c.overlay.style.opacity = '1';
        });

        // Update card state
        if (c.card) {
            c.card.classList.remove('safe-state');
            c.card.classList.add(c.alertClass);
        }
        if (c.led) c.led.className = `sensor-led ${c.ledClass}`;
        if (c.txt) c.txt.textContent = c.alertText;

        // Track active alerts
        state.activeAlerts.add(type);

        // Log it
        state.alertCount++;
        addAlertLog(c.logIcon, c.logName, 'Sensör tehlike algıladı!', c.logClass);

        // Play browser notification sound (visual flash on body)
        flashScreen(type);

    } else {
        // Resolve alert
        c.overlay.style.display = 'none';
        if (c.card) {
            c.card.classList.remove(c.alertClass, 'alert-state', 'seat-alert', 'door-alert');
            c.card.classList.add('safe-state');
        }
        if (c.led) c.led.className = 'sensor-led safe';
        if (c.txt) c.txt.textContent = c.safeText;
        state.activeAlerts.delete(type);
    }

    updateSafetyScore();
    
    // YENİ: Sesleri öncelik sırasına göre çal/durdur (Door > Seat > Seatbelt)
    updateAudioPriority();
}

/**
 * dismissAlert - Uyarı ekranını kullanıcı kapatır
 */
function dismissAlert(type) {
    const overlayMap = {
        seatbelt: els.overlaySeatbelt,
        seat: els.overlaySeat,
        door: els.overlayDoor
    };
    const overlay = overlayMap[type];
    if (overlay) {
        overlay.style.opacity = '0';
        setTimeout(() => {
            overlay.style.display = 'none';
        }, 300);
    }
    // NOTE: Dismissing doesn't clear the alert state — sensor must go back to safe
    // But for UX we allow manual dismiss:
    addAlertLog('👁', type === 'seatbelt' ? 'Emniyet Kemeri' : type === 'seat' ? 'Koltuk' : 'Kapı',
                'Uyarı görüldü', 'resolved-log');
}

/**
 * resetAllAlerts - Tüm uyarıları sıfırla (test/simülasyon)
 */
function resetAllAlerts() {
    ['seatbelt', 'seat', 'door'].forEach(t => triggerAlert(t, false));
}

// ==================== SAFETY SCORE ====================
function updateSafetyScore() {
    const activeCount = state.activeAlerts.size;
    const score = Math.max(0, Math.round(100 - (activeCount / 3) * 100));
    const circumference = 314;
    const offset = circumference - (score / 100) * circumference;

    if (els.safetyArc) {
        els.safetyArc.style.strokeDashoffset = offset;
        if (score >= 80) {
            els.safetyArc.style.stroke = '#00E676';
        } else if (score >= 40) {
            els.safetyArc.style.stroke = '#FF6D00';
        } else {
            els.safetyArc.style.stroke = '#FF1744';
        }
    }

    if (els.scoreNumber) {
        els.scoreNumber.textContent = score;
        els.scoreNumber.style.color = score >= 80 ? '#00E676' : score >= 40 ? '#FF6D00' : '#FF1744';
    }
}

// ==================== SCREEN FLASH ====================
function flashScreen(type) {
    const colors = {
        seatbelt: 'rgba(255,23,68,0.15)',
        seat:     'rgba(255,109,0,0.15)',
        door:     'rgba(255,214,0,0.12)'
    };
    const flash = document.createElement('div');
    flash.style.cssText = `
        position:fixed; inset:0; z-index:999; pointer-events:none;
        background:${colors[type]};
        animation: flash-out 0.8s ease-out forwards;
    `;
    // Add keyframes dynamically
    if (!document.getElementById('flash-style')) {
        const style = document.createElement('style');
        style.id = 'flash-style';
        style.textContent = `@keyframes flash-out {
            0% { opacity: 1; }
            100% { opacity: 0; }
        }`;
        document.head.appendChild(style);
    }
    document.body.appendChild(flash);
    setTimeout(() => flash.remove(), 900);
}

// ==================== TCP CONNECTION ====================
/**
 * toggleConnection - TCP bağlantısını aç/kapat
 * WebSocket gateway üzerinden gerçek TCP bağlanması için
 * bir ara katman sunucu (Python/Node) gerekir.
 * Şimdilik WebSocket simülasyonu yapılıyor.
 */
function toggleConnection() {
    if (state.tcpConnected) {
        disconnectTCP();
    } else {
        connectTCP();
    }
}

function connectTCP() {
    const ip   = document.getElementById('tcp-ip')?.value || tcpConfig.ip;
    const port = document.getElementById('tcp-port')?.value || tcpConfig.port;
    const poll = parseInt(document.getElementById('tcp-poll')?.value || tcpConfig.poll);

    tcpConfig = { ip, port, poll };

    // Update UI to "connecting"
    setConnectionStatus('connecting', `${ip}:${port}`);

    // Try WebSocket connection (expects a WS bridge server at ws://localhost:8765)
    const wsUrl = `ws://localhost:8765`;

    try {
        state.ws = new WebSocket(wsUrl);

        state.ws.onopen = () => {
            setConnectionStatus('connected', `${ip}:${port}`);
            state.tcpConnected = true;
            if (els.connectBtn) els.connectBtn.textContent = 'BAĞLANTIYI KES';

            // Send connection command to WS bridge
            state.ws.send(JSON.stringify({
                cmd: 'connect',
                ip: ip,
                port: parseInt(port)
            }));

            // Start polling
            state.pollingInterval = setInterval(() => {
                if (state.ws && state.ws.readyState === WebSocket.OPEN) {
                    state.ws.send(JSON.stringify({ cmd: 'read_coils' }));
                }
            }, poll);

            addAlertLog('🔗', 'TCP Bağlantı', `${ip}:${port} bağlandı`, 'resolved-log');
        };

        state.ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                handleTCPData(data);
            } catch(e) {
                console.error('TCP data parse error:', e);
            }
        };

        state.ws.onerror = () => {
            // WebSocket not available — start demo simulation instead
            startDemoSimulation(ip, port);
        };

        state.ws.onclose = () => {
            if (state.tcpConnected) {
                setConnectionStatus('disconnected', `${ip}:${port}`);
                state.tcpConnected = false;
                if (els.connectBtn) els.connectBtn.textContent = 'BAĞLAN';
                clearInterval(state.pollingInterval);
            }
        };

    } catch(e) {
        startDemoSimulation(ip, port);
    }
}

function disconnectTCP() {
    if (state.ws) {
        state.ws.close();
        state.ws = null;
    }
    clearInterval(state.pollingInterval);
    state.tcpConnected = false;
    setConnectionStatus('disconnected', tcpConfig.ip + ':' + tcpConfig.port);
    if (els.connectBtn) els.connectBtn.textContent = 'BAĞLAN';
    addAlertLog('🔌', 'TCP', 'Bağlantı kesildi', 'resolved-log');
}

function setConnectionStatus(status, address) {
    if (!els.tcpDot || !els.tcpLabel || !els.tcpAddress) return;

    els.tcpAddress.textContent = address || '';

    if (status === 'connected') {
        els.tcpDot.className = 'status-dot connected';
        els.tcpLabel.textContent = 'BAĞLI';
        els.tcpLabel.style.color = '#00E676';
    } else if (status === 'connecting') {
        els.tcpDot.className = 'status-dot';
        els.tcpDot.style.background = '#FFD600';
        els.tcpLabel.textContent = 'BAĞLANIYOR...';
        els.tcpLabel.style.color = '#FFD600';
    } else {
        els.tcpDot.className = 'status-dot disconnected';
        els.tcpLabel.textContent = 'BAĞLANTI YOK';
        els.tcpLabel.style.color = '#FF1744';
    }
}

/**
 * handleTCPData - Gelen TCP / WebSocket verisini işle
 * Beklenen format:
 * {
 *   coils: {
 *     seatbelt: true/false,  // true = UYARI (kemer takılı değil)
 *     seat: true/false,      // true = UYARI (operatör kalktı)
 *     door: true/false       // true = UYARI (kapı açık)
 *   }
 * }
 * 
 * veya raw format:
 * { seatbelt: 0/1, seat: 0/1, door: 0/1 }
 */
function handleTCPData(data) {
    // Normalize
    let coils = data.coils || data;

    if (typeof coils.seatbelt !== 'undefined') {
        triggerAlert('seatbelt', !!coils.seatbelt);
    }
    if (typeof coils.seat !== 'undefined') {
        triggerAlert('seat', !!coils.seat);
    }
    if (typeof coils.door !== 'undefined') {
        triggerAlert('door', !!coils.door);
    }
}

// ==================== DEMO SIMULATION ====================
/**
 * startDemoSimulation - WebSocket yoksa demo modu
 * Gerçek bir TCP bridge sunucusu bağlı değilken demo veri üretir.
 */
function startDemoSimulation(ip, port) {
    console.log('[DEMO MODE] WebSocket bridge bulunamadı, demo simülasyon başlatılıyor.');
    
    setConnectionStatus('connected', `${ip}:${port} [DEMO]`);
    state.tcpConnected = true;
    if (els.connectBtn) els.connectBtn.textContent = 'BAĞLANTIYI KES';
    addAlertLog('🎭', 'Demo Mod', 'WS bridge yok, simülasyon aktif', 'resolved-log');

    let demoStep = 0;
    const demoSequence = [
        // Format: [delay_ms, type, isAlert]
        [3000, 'seatbelt', true],
        [4000, 'seatbelt', false],
        [5000, 'door', true],
        [4000, 'door', false],
        [3000, 'seat', true],
        [5000, 'seat', false],
        [2000, null, null],  // pause
    ];

    function runNextDemo() {
        if (!state.tcpConnected) return;
        const step = demoSequence[demoStep % demoSequence.length];
        demoStep++;
        setTimeout(() => {
            if (step[1]) triggerAlert(step[1], step[2]);
            runNextDemo();
        }, step[0]);
    }

    runNextDemo();
}

// ==================== PARTICLES ====================
(function initParticles() {
    const canvas = document.getElementById('particles-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles = Array.from({length: 40}, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: -Math.random() * 0.4 - 0.1,
        size: Math.random() * 2 + 0.5,
        alpha: Math.random() * 0.4 + 0.1,
        color: Math.random() > 0.5 ? [245, 166, 35] : [100, 180, 255]
    }));

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;
            if (p.y < -5) { p.y = canvas.height + 5; p.x = Math.random() * canvas.width; }
            if (p.x < -5) p.x = canvas.width + 5;
            if (p.x > canvas.width + 5) p.x = -5;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${p.color[0]},${p.color[1]},${p.color[2]},${p.alpha})`;
            ctx.fill();
        });
        requestAnimationFrame(animate);
    }
    animate();

    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
})();

// ==================== INIT ====================
(function init() {
    // Initialize safe state on all cards
    ['cardSeatbelt', 'cardSeat', 'cardDoor'].forEach(key => {
        if (els[key]) els[key].classList.add('safe-state');
    });

    // Clock
    updateClock();
    setInterval(updateClock, 1000);
    setInterval(updateUptime, 1000);

    // Initial safety score
    updateSafetyScore();

    // Statik başlık kullanılıyor, dinamik selamlama kaldırıldı.

    // Mine image fallback colors if image not found
    const mineImg = document.getElementById('mine-photo');
    if (mineImg) {
        mineImg.onerror = function() {
            this.style.display = 'none';
            const container = document.getElementById('mine-display');
            if (container) {
                container.style.background = `
                    linear-gradient(135deg, 
                        #0a1520 0%, 
                        #0d1e2e 30%, 
                        #0a2030 70%, 
                        #060d14 100%)
                `;
            }
        };
    }

    console.log('%cTÜPRAG MADEN İŞLETMESİ', 'color:#F5A623;font-size:18px;font-weight:bold;');
    console.log('%cGüvenlik Kontrol Paneli v1.0', 'color:#8BA5BF;font-size:12px;');
    console.log('%cTCP Veri Formatı:', 'color:#00E676;');
    console.log('%c{ coils: { seatbelt: true/false, seat: true/false, door: true/false } }', 'color:#ccc;font-family:monospace;');
})();

// ==================== KEYBOARD SHORTCUTS ====================
document.addEventListener('keydown', (e) => {
    if (e.key === '1') triggerAlert('seatbelt', !state.seatbelt);
    if (e.key === '2') triggerAlert('seat', !state.seat);
    if (e.key === '3') triggerAlert('door', !state.door);
    if (e.key === 'r' || e.key === 'R') resetAllAlerts();
    if (e.key === 'Escape') {
        ['seatbelt', 'seat', 'door'].forEach(t => dismissAlert(t));
    }
});

// ==================== HISTORY MODAL ====================
function toggleHistoryModal() {
    const modal = document.getElementById('history-modal');
    if (!modal) return;
    
    if (modal.style.display === 'none' || modal.style.display === '') {
        modal.style.display = 'flex';
    } else {
        modal.style.display = 'none';
    }
}

// ==================== ALERT LOGGING ====================
function addAlertLog(icon, title, desc, cssClass) {
    const list = document.getElementById('alert-log-list');
    if (!list) return;

    const time = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    const logItem = document.createElement('div');
    logItem.className = `log-item ${cssClass}`;
    
    logItem.innerHTML = `
        <div class="log-time">${time}</div>
        <div class="log-content">
            <div class="log-title">${icon} ${title}</div>
            <div class="log-desc">${desc}</div>
        </div>
    `;
    
    list.prepend(logItem);
    
    // Sadece son 50 logu tutalım
    while (list.children.length > 50) {
        list.removeChild(list.lastChild);
    }
}

// ==================== AUDIO WARNINGS ====================
const audioAlerts = {
    'seatbelt': new Audio('Kemer.mp3'),
    'seat': new Audio('Koltuk.mp3'),
    'door': new Audio('Kapı.mp3')
};

// Siren iptal edildi

// Web Audio API ile sesi %400 (4 kat) artırma (Ses Güçlendirici)
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
const gainNode = audioCtx.createGain();
gainNode.gain.value = 4.0; // Sesi 4 katına çıkar (İsteğe göre 4.0 veya 5.0 yapılabilir)
gainNode.connect(audioCtx.destination);

// Konuşma seslerini döngüye al ve güçlendiriciye bağla
Object.values(audioAlerts).forEach(audio => {
    audio.loop = true;
    audio.volume = 1.0;
    
    // Sesi güçlendirici köprüden geçir
    const source = audioCtx.createMediaElementSource(audio);
    source.connect(gainNode);
});

function playAlertAudio(type) {
    // Ses motoru uyku modundaysa uyandır
    if (audioCtx.state === 'suspended') {
        audioCtx.resume();
    }
    
    if (audioAlerts[type]) {
        audioAlerts[type].currentTime = 0;
        audioAlerts[type].play().catch(e => console.error("Ses oynatma hatası:", e));
    }
}

function stopAlertAudio(type) {
    if (audioAlerts[type]) {
        audioAlerts[type].pause();
        audioAlerts[type].currentTime = 0;
    }
}

// ==================== AUDIO PRIORITY SYSTEM ====================
let currentAudioPriority = null;

function updateAudioPriority() {
    let newPriority = null;

    // 1. En yüksek önceliği belirle
    if (state.door) newPriority = 'door';
    else if (state.seat) newPriority = 'seat';
    else if (state.seatbelt) newPriority = 'seatbelt';

    // Eğer öncelik değişmediyse, zaten çalan sesi başa sarma (kekelemeyi önler)
    if (currentAudioPriority === newPriority) return;

    // Öncelik değiştiyse eskiyi durdur
    ['door', 'seat', 'seatbelt'].forEach(stopAlertAudio);

    // Yeni önceliği çal
    if (newPriority) {
        playAlertAudio(newPriority);
    }
    
    currentAudioPriority = newPriority;
}

// ==================== NATIVE FLUTTER INTEGRATION ====================
// Flutter'daki yerel Modbus TCP kodunun UI'ı güncelleyebilmesi için köprü fonksiyonu
window.handleModbusUpdate = function(type, isFault) {
    triggerAlert(type, isFault);
};

window.updateConnectionStatus = function(isConnected, errorMsg) {
    if (isConnected) {
        els.tcpDot.style.background = '#00FF2A';
        els.tcpDot.style.boxShadow = '0 0 15px #00FF2A';
        els.tcpLabel.textContent = 'BAĞLI (MODBUS)';
        els.tcpLabel.style.color = '#00FF2A';
        if (errorMsg) addAlertLog('🔗', 'TCP Bağlandı', errorMsg, 'resolved-log');
    } else {
        els.tcpDot.style.background = '#FF1744';
        els.tcpDot.style.boxShadow = '0 0 15px #FF1744';
        els.tcpLabel.textContent = 'BAĞLANTI KOPTU';
        els.tcpLabel.style.color = '#FF1744';
        if (errorMsg) addAlertLog('❌', 'Bağlantı Hatası', errorMsg, 'seatbelt-log');
    }
};

// ==================== GUNCELLEME KOPRUSU ====================
// Flutter tarafi yeni bir arayuz paketini devreye aldiginda, sayfanin gercekten
// acildigini bu sinyalle dogrular. Sinyal 15 saniye icinde gelmezse paket
// otomatik olarak geri alinir; bu blok SILINMEMELIDIR.
(function notifyBundleBoot() {
    function send() {
        try {
            if (window.UpdateChannel && window.UpdateChannel.postMessage) {
                window.UpdateChannel.postMessage('BOOT_OK');   // Android
            } else if (window.chrome && window.chrome.webview) {
                window.chrome.webview.postMessage('BOOT_OK');  // Windows
            }
        } catch (e) {
            // Kopru yoksa (tarayicida acildiysa) sessiz gec.
        }
    }
    if (document.readyState === 'complete') send();
    else window.addEventListener('load', send);
})();
